async function generatePDF(){
    document.getElementById("downloadBtn").innerHTML = "Currently downloading. Please wait...";

    // Download
    // var downloading = document.getElementById("printableArea");

    // End of Download
    // document.getElementById("downloadBtn").innerHTML = "<i class='fa-regular fa-print'></i>";
}