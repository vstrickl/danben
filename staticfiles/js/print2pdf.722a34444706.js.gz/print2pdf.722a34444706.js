async function generatePDF(){
    var downloading = document.getElementById("downloadBtn").innerHTML = "Currently downloading. Please wait...";
    console.log(downloading)

    // Download
    // var printing = document.getElementById("printableArea");

    // End of Download
    // document.getElementById("downloadBtn").innerHTML = "<i class='fa-regular fa-print'></i>";
}